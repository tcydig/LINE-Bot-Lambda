import os
import sys
import logging
import json
import urllib.request
from linebot import LineBotApi
from linebot.models import TextSendMessage

logger = logging.getLogger()
logger.setLevel(logging.ERROR)

channel_access_token = os.environ['CHANNEL_ACCESS_TOKEN']
user_id = os.environ['USER_ID']

if user_id is None:
    logger.error('Specify user_id as environment variable.')
    sys.exit(1)
if channel_access_token is None:
    logger.error('Specify LINE_CHANNEL_ACCESS_TOKEN as environment variable.')
    sys.exit(1)
line_bot_api = LineBotApi(channel_access_token)

def lambda_handler(event, context):

    messages = TextSendMessage(text="ぷっしゅめっせーじです。やあ!")
    line_bot_api.push_message(
            user_id,
            messages=messages)

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
